"""
------------------------------------------------------------------------
Lab 8, Task 4
------------------------------------------------------------------------
Author: Mike Bangar
ID:     169073786
Email:  bang3786@mylaurier.ca
__updated__ = '2023-11-10'
------------------------------------------------------------------------
"""

from functions import generate_integer_list

print(generate_integer_list(0, 0, 100))

print(generate_integer_list(10, 0, 100))

print(generate_integer_list(4, 99, 147))