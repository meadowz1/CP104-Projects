"""
------------------------------------------------------------------------
Lab 8, Task 1
------------------------------------------------------------------------
Author: Mike Bangar
ID:     169073786
Email:  bang3786@mylaurier.ca
__updated__ = '2023-11-10'
------------------------------------------------------------------------
"""

from functions import get_weekday_name

print(get_weekday_name(1))

print(get_weekday_name(2))

print(get_weekday_name(3))

print(get_weekday_name(4))

print(get_weekday_name(5))

print(get_weekday_name(6))

print(get_weekday_name(7))
